function Autorizar() {
  return (
    <div>
      <h2>Autorizar Votos Observados</h2>
      <p>Lista de solicitudes pendientes (conectarse al backend más adelante).</p>
    </div>
  );
}

export default Autorizar;
